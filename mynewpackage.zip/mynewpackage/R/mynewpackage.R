myfun <- function(x){x + 7}
myfun2 <- function(x){x * 7}
